"""Models subpackage for Informer."""

from .informer import Informer

__all__ = ["Informer"]