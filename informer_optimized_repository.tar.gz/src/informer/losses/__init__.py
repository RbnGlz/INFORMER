"""Losses subpackage for Informer."""

# Re-export from the original neuralforecast structure
# This maintains compatibility while allowing future custom losses

__all__ = []